package com.notchisland

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat

/** Menyalakan lagi Notch Island setelah HP reboot (kalau sebelumnya user menyalakannya). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != "android.intent.action.QUICKBOOT_POWERON" &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        if (!IslandState.isEnabled(context)) return
        if (!Settings.canDrawOverlays(context)) return
        try {
            ContextCompat.startForegroundService(
                context, Intent(context, IslandService::class.java)
            )
        } catch (_: Exception) {
        }
    }
}
