package com.notchisland

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.graphics.drawable.toBitmap

/**
 * Menangkap notifikasi, panggilan (dari app apa pun), dan sesi media aktif,
 * lalu mengirimnya ke IslandState. Butuh izin "Akses notifikasi".
 */
class NotifListener : NotificationListenerService() {

    private var sessionManager: MediaSessionManager? = null
    private var controllers: List<MediaController> = emptyList()

    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = publishMedia()
        override fun onMetadataChanged(metadata: MediaMetadata?) = publishMedia()
        override fun onSessionDestroyed() = publishMedia()
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> setControllers(list) }

    // ---- kata kunci untuk mengenali panggilan (Indonesia + Inggris) ----
    private val incomingWords = Regex(
        "incoming (voice |video |audio |group )?call|is calling|calling you|" +
                "panggilan (suara |video |grup )?masuk|memanggil|menelepon|menelpon",
        RegexOption.IGNORE_CASE
    )
    private val missedWords = Regex(
        "missed|tak terjawab|tidak terjawab|terlewat",
        RegexOption.IGNORE_CASE
    )
    private val answerWords = Regex(
        "answer|accept|pick up|jawab|terima|angkat",
        RegexOption.IGNORE_CASE
    )
    private val declineWords = Regex(
        "decline|reject|dismiss|hang ?up|end call|cancel|tolak|akhiri|tutup|batal",
        RegexOption.IGNORE_CASE
    )
    private val notCallCategories = setOf(
        Notification.CATEGORY_MESSAGE, Notification.CATEGORY_EMAIL,
        Notification.CATEGORY_ALARM, Notification.CATEGORY_REMINDER,
        Notification.CATEGORY_EVENT, Notification.CATEGORY_PROMO,
        Notification.CATEGORY_RECOMMENDATION
    )

    override fun onListenerConnected() {
        super.onListenerConnected()
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            sessionManager = msm
            val cn = ComponentName(this, NotifListener::class.java)
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            setControllers(msm.getActiveSessions(cn))
        } catch (_: SecurityException) {
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {
        }
        setControllers(emptyList())
        IslandState.call.value = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        val ex = n.extras ?: return

        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString().orEmpty()

        // Panggilan dicek dulu, karena notifikasi call biasanya "ongoing".
        if (handleCall(sbn, n, title, text)) return

        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (ex.getString(Notification.EXTRA_TEMPLATE)?.contains("MediaStyle") == true) return
        if (title.isBlank() && text.isBlank()) return

        val (appName, icon) = loadApp(sbn.packageName)

        IslandState.notif.value = NotifInfo(
            key = sbn.key,
            appName = appName,
            title = title.ifBlank { appName },
            text = text,
            icon = icon,
            intent = n.contentIntent
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (IslandState.call.value?.key == sbn.key) {
            IslandState.call.value = null
        }
    }

    // ---------- panggilan ----------

    /** @return true kalau notifikasi ini adalah panggilan (sudah ditangani). */
    private fun handleCall(
        sbn: StatusBarNotification,
        n: Notification,
        title: String,
        text: String
    ): Boolean {
        val ex = n.extras ?: return false
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return false

        val both = "$title $text"
        if (missedWords.containsMatchIn(both)) return false // panggilan tak terjawab = notif biasa

        val template = ex.getString(Notification.EXTRA_TEMPLATE).orEmpty()
        val callStyle = template.contains("CallStyle")
        val categoryCall = n.category == Notification.CATEGORY_CALL
        val keyword = n.category !in notCallCategories && incomingWords.containsMatchIn(both)
        if (!callStyle && !categoryCall && !keyword) return false

        // Tombol Jawab / Tolak dari aksi notifikasi
        val actions = n.actions?.toList().orEmpty()
        fun titleOf(a: Notification.Action) = a.title?.toString().orEmpty()
        var answer: PendingIntent? =
            actions.firstOrNull { answerWords.containsMatchIn(titleOf(it)) }?.actionIntent
        var decline: PendingIntent? =
            actions.firstOrNull { declineWords.containsMatchIn(titleOf(it)) }?.actionIntent
        if (callStyle && answer == null && decline == null && actions.size == 2) {
            decline = actions[0].actionIntent
            answer = actions[1].actionIntent
        }

        // "android.callType": 1 = masuk, 2 = berlangsung, 3 = screening (CallStyle, Android 12+)
        val callType = ex.getInt("android.callType", 0)
        val incoming = when {
            callStyle && callType == 2 -> false
            callStyle && (callType == 1 || callType == 3) -> true
            else -> n.fullScreenIntent != null || answer != null || keyword
        }

        val (appName, icon) = loadApp(sbn.packageName)
        val previous = IslandState.call.value
        val sameCall = previous != null && previous.key == sbn.key && previous.incoming == incoming

        // Notifikasi call sering di-update berkali-kali; jangan re-emit kalau tidak berubah.
        if (sameCall && previous!!.caller == title && previous.subtitle == text) return true

        IslandState.call.value = CallInfo(
            key = sbn.key,
            appName = appName,
            caller = title.ifBlank { appName },
            subtitle = text,
            icon = icon,
            incoming = incoming,
            content = n.contentIntent ?: n.fullScreenIntent,
            answer = answer,
            decline = decline,
            startedAt = if (sameCall) previous!!.startedAt else System.currentTimeMillis()
        )
        return true
    }

    private fun loadApp(pkg: String): Pair<String, android.graphics.Bitmap?> {
        val pm = packageManager
        val name = try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) {
            pkg
        }
        val icon = try {
            pm.getApplicationIcon(pkg).toBitmap(96, 96)
        } catch (_: Exception) {
            null
        }
        return name to icon
    }

    // ---------- media ----------

    private fun setControllers(list: List<MediaController>?) {
        controllers.forEach { it.unregisterCallback(controllerCallback) }
        controllers = list.orEmpty()
        controllers.forEach { it.registerCallback(controllerCallback) }
        publishMedia()
    }

    private fun publishMedia() {
        val pick = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: controllers.firstOrNull()
        IslandState.controller = pick

        val md = pick?.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        if (pick == null || title.isNullOrBlank()) {
            IslandState.media.value = null
            return
        }
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: ""
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

        IslandState.media.value = MediaInfo(
            title = title,
            artist = artist,
            art = art,
            isPlaying = pick.playbackState?.state == PlaybackState.STATE_PLAYING
        )
    }
}
