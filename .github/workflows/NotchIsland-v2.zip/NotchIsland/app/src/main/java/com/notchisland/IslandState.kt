package com.notchisland

import android.app.PendingIntent
import android.content.Context
import android.graphics.Bitmap
import android.media.session.MediaController
import kotlinx.coroutines.flow.MutableStateFlow

/** Pengaturan posisi/ukuran pill. Bisa dikalibrasi dari layar setup. */
data class NotchConfig(
    val gapDp: Int = 36,      // lebar celah di tengah (tempat kamera punch-hole)
    val sideDp: Int = 72,     // lebar area kiri & kanan kamera
    val heightDp: Int = 34,   // tinggi pill saat compact
    val topDp: Int = 4        // jarak dari tepi atas layar
)

data class NotifInfo(
    val key: String,
    val appName: String,
    val title: String,
    val text: String,
    val icon: Bitmap?,
    val intent: PendingIntent?,
    val time: Long = System.currentTimeMillis()
)

data class MediaInfo(
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val isPlaying: Boolean
)

data class ChargeInfo(val percent: Int)

/** Panggilan (masuk / sedang berlangsung) dari aplikasi apa pun yang memposting notifikasi call. */
data class CallInfo(
    val key: String,
    val appName: String,
    val caller: String,
    val subtitle: String,
    val icon: Bitmap?,
    val incoming: Boolean,
    val content: PendingIntent?,
    val answer: PendingIntent?,
    val decline: PendingIntent?,
    val startedAt: Long = System.currentTimeMillis()
)

/** State bersama antara service, listener, dan UI (semua satu proses). */
object IslandState {
    val config = MutableStateFlow(NotchConfig())
    val notif = MutableStateFlow<NotifInfo?>(null)
    val charge = MutableStateFlow<ChargeInfo?>(null)
    val media = MutableStateFlow<MediaInfo?>(null)
    val call = MutableStateFlow<CallInfo?>(null)

    @Volatile
    var controller: MediaController? = null

    private const val PREFS = "notch_prefs"

    /** Dipakai BootReceiver: auto-start hanya kalau user terakhir menyalakan notch. */
    fun setEnabled(ctx: Context, enabled: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("enabled", enabled).apply()
    }

    fun isEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("enabled", false)

    fun loadConfig(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val d = NotchConfig()
        config.value = NotchConfig(
            gapDp = p.getInt("gap", d.gapDp),
            sideDp = p.getInt("side", d.sideDp),
            heightDp = p.getInt("height", d.heightDp),
            topDp = p.getInt("top", d.topDp)
        )
    }

    fun saveConfig(ctx: Context) {
        val c = config.value
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("gap", c.gapDp)
            .putInt("side", c.sideDp)
            .putInt("height", c.heightDp)
            .putInt("top", c.topDp)
            .apply()
    }
}
