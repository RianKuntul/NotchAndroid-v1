package com.notchisland

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

private val Green = Color(0xFF30D158)
private val GreenDark = Color(0xFF12B981)
private val Bg = Color(0xFF0A0A0C)
private val CardBg = Color(0xFF161619)
private val Subtle = Color(0xFF9A9AA0)

class MainActivity : ComponentActivity() {

    private val tick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        IslandState.loadConfig(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    Screen(tick.intValue)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick.intValue++
    }
}

@Composable
private fun Screen(tick: Int) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val cfg by IslandState.config.collectAsState()
    var running by remember(tick) { mutableStateOf(IslandService.running) }

    val overlayOk = remember(tick) { Settings.canDrawOverlays(ctx) }
    val listenerOk = remember(tick) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    val batteryOk = remember(tick) {
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager)
            .isIgnoringBatteryOptimizations(ctx.packageName)
    }
    val postOk = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
    }
    val postLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ---------- hero ----------
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.verticalGradient(listOf(Color(0xFF2E2E33), Color(0xFF131316)))
                    ),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.material3.Icon(
                    painterResource(R.drawable.ic_bolt), null,
                    tint = Green, modifier = Modifier.size(26.dp)
                )
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Notch Island", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Dynamic Island buat Android",
                    fontSize = 13.sp,
                    color = Subtle
                )
            }
        }

        // ---------- status ----------
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusDot(active = running && overlayOk)
            Text(
                if (running) "Notch aktif di atas" else "Notch belum nyala",
                fontSize = 13.sp,
                color = if (running) Green else Subtle,
                fontWeight = FontWeight.SemiBold
            )
        }

        // ---------- tombol sakti ----------
        PrimaryButton(
            label = if (running) "Matikan Notch" else "Nyalakan Notch",
            enabled = overlayOk
        ) {
            val i = Intent(ctx, IslandService::class.java)
            if (running) {
                ctx.stopService(i)
                IslandState.setEnabled(ctx, false)
                running = false
            } else {
                ContextCompat.startForegroundService(ctx, i)
                IslandState.setEnabled(ctx, true)
                running = true
            }
        }
        if (!overlayOk) {
            Text(
                "Aktifkan izin \u201CTampil di atas app lain\u201D dulu di atas",
                fontSize = 12.sp, color = Subtle
            )
        }

        // ---------- izin ----------
        SectionTitle("Izin yang dibutuhkan")
        PermCard(
            "1. Tampil di atas app lain",
            "Wajib. Supaya pill bisa muncul di atas layar.",
            overlayOk, "Izinkan"
        ) {
            open(
                ctx, Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${ctx.packageName}")
                )
            )
        }
        PermCard(
            "2. Akses notifikasi",
            "Untuk membaca notifikasi & kontrol musik. Kalau tombolnya abu-abu: " +
                    "Info app → titik tiga → \u201CIzinkan setelan terbatas\u201D, lalu coba lagi.",
            listenerOk, "Buka setelan"
        ) {
            open(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        if (Build.VERSION.SDK_INT >= 33) {
            PermCard(
                "3. Izin kirim notifikasi",
                "Untuk notifikasi service yang berjalan di latar belakang.",
                postOk, "Izinkan"
            ) { postLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
        }
        PermCard(
            "4. Bebas hemat baterai",
            "Biar tidak dimatikan HyperOS. Sebaiknya juga aktifkan Autostart & kunci app di recents.",
            batteryOk, "Atur"
        ) {
            open(
                ctx, Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:${ctx.packageName}")
                )
            )
        }
        OutlinedButton(
            onClick = { openAutostart(ctx) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Buka setelan Autostart (Xiaomi/Poco)")
        }

        // ---------- tes tampilan ----------
        SectionTitle("Tes tampilan")

        val chipMod = Modifier.weight(1f)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = {
                IslandState.notif.value = NotifInfo(
                    "test", "Pesan", "Budi", "Woi besok jadi nongkrong nggak?", null, null
                )
            }, modifier = chipMod) { Text("Notif") }
            OutlinedButton(onClick = {
                IslandState.charge.value = ChargeInfo(67)
            }, modifier = chipMod) { Text("Charge") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = {
                IslandState.media.value = MediaInfo("Judul Lagu", "Nama Artis", null, true)
            }, modifier = chipMod) { Text("Musik") }
            OutlinedButton(onClick = {
                IslandState.call.value = CallInfo(
                    key = "test-call", appName = "WhatsApp", caller = "Budi",
                    subtitle = "Panggilan suara masuk", icon = null, incoming = true,
                    content = null, answer = null, decline = null
                )
            }, modifier = chipMod) { Text("Telepon") }
        }

        // ---------- kalibrasi ----------
        SectionTitle("Kalibrasi kamera")
        Text(
            "Geser sampai celah tengah pas dengan punch-hole kamera " +
                    "(nyalakan notch & tekan tombol tes dulu).",
            fontSize = 12.sp, color = Subtle
        )
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg)
        ) {
            Column(
                Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SliderRow("Celah tengah: ${cfg.gapDp} dp", cfg.gapDp, 10, 90) {
                    IslandState.config.value = cfg.copy(gapDp = it)
                }
                SliderRow("Lebar kiri/kanan: ${cfg.sideDp} dp", cfg.sideDp, 40, 120) {
                    IslandState.config.value = cfg.copy(sideDp = it)
                }
                SliderRow("Tinggi pill: ${cfg.heightDp} dp", cfg.heightDp, 24, 50) {
                    IslandState.config.value = cfg.copy(heightDp = it)
                }
                SliderRow("Jarak dari atas: ${cfg.topDp} dp", cfg.topDp, 0, 30) {
                    IslandState.config.value = cfg.copy(topDp = it)
                }
                PrimaryButton(
                    label = "Simpan kalibrasi",
                    enabled = true
                ) { IslandState.saveConfig(ctx) }
            }
        }

        Spacer(Modifier.height(16.dp))
    }
}

// ---------- komponen kecil ----------

@Composable
private fun StatusDot(active: Boolean) {
    if (active) {
        val t = rememberInfiniteTransition(label = "dot")
        val alpha by t.animateFloat(
            initialValue = 0.35f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
            label = "dotAlpha"
        )
        Box(
            Modifier
                .size(9.dp)
                .graphicsLayer { this.alpha = alpha }
                .clip(CircleShape)
                .background(Green)
        )
    } else {
        Box(
            Modifier
                .size(9.dp)
                .clip(CircleShape)
                .background(Color(0xFF4A4A52))
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            Modifier
                .size(width = 4.dp, height = 18.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Green)
        )
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PrimaryButton(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val inter = remember { MutableInteractionSource() }
    val pressed by inter.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(stiffness = 500f),
        label = "pScale"
    )
    Box(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(27.dp))
            .background(
                if (enabled) Brush.horizontalGradient(listOf(Green, GreenDark))
                else Brush.horizontalGradient(listOf(Color(0xFF2A2A2E), Color(0xFF2A2A2E)))
            )
            .clickable(
                interactionSource = inter,
                indication = null,
                enabled = enabled
            ) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (enabled) Color.Black else Color(0xFF8A8A92),
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )
    }
}

@Composable
private fun PermCard(
    title: String,
    desc: String,
    ok: Boolean,
    action: String,
    onClick: () -> Unit
) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StatusDot(ok)
                    Text(if (ok) "Aktif" else "Belum", fontSize = 12.sp, color = Subtle)
                }
            }
            Text(desc, fontSize = 13.sp, color = Subtle)
            if (!ok) {
                OutlinedButton(onClick = onClick) { Text(action) }
            }
        }
    }
}

@Composable
private fun SliderRow(label: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Column {
        Text(label, fontSize = 13.sp, color = Subtle)
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = min.toFloat()..max.toFloat()
        )
    }
}

private fun open(ctx: Context, intent: Intent) {
    try {
        ctx.startActivity(intent)
    } catch (_: Exception) {
        try {
            ctx.startActivity(
                Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:${ctx.packageName}")
                )
            )
        } catch (_: Exception) {
        }
    }
}

private fun openAutostart(ctx: Context) {
    val i = Intent().setComponent(
        ComponentName(
            "com.miui.securitycenter",
            "com.miui.permcenter.autostart.AutoStartManagementActivity"
        )
    )
    open(ctx, i)
}
