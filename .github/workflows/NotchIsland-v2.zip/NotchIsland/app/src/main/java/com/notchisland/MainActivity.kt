package com.notchisland

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private val tick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        IslandState.loadConfig(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    Screen(tick.intValue)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick.intValue++
    }
}

@Composable
private fun Screen(tick: Int) {
    val ctx = LocalContext.current
    val cfg by IslandState.config.collectAsState()
    var running by remember(tick) { mutableStateOf(IslandService.running) }

    val overlayOk = remember(tick) { Settings.canDrawOverlays(ctx) }
    val listenerOk = remember(tick) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    val batteryOk = remember(tick) {
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager)
            .isIgnoringBatteryOptimizations(ctx.packageName)
    }
    val postOk = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
    }
    val postLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    Column(
        Modifier
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Notch Island", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(
            "Dynamic Island / notch untuk Android. Kasih semua izin di bawah, lalu nyalakan.",
            fontSize = 14.sp
        )

        PermRow(
            "1. Tampil di atas app lain",
            "Wajib. Supaya pill bisa muncul di atas layar.",
            overlayOk, "Izinkan"
        ) {
            open(
                ctx, Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${ctx.packageName}")
                )
            )
        }

        PermRow(
            "2. Akses notifikasi",
            "Untuk membaca notifikasi & kontrol musik. Kalau tombolnya abu-abu: " +
                    "Info app → titik tiga → \"Izinkan setelan terbatas\", lalu coba lagi.",
            listenerOk, "Buka setelan"
        ) {
            open(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        if (Build.VERSION.SDK_INT >= 33) {
            PermRow(
                "3. Izin kirim notifikasi",
                "Untuk notifikasi service yang berjalan di latar belakang.",
                postOk, "Izinkan"
            ) { postLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
        }

        PermRow(
            "4. Bebas hemat baterai",
            "Biar tidak dimatikan HyperOS. Sebaiknya juga aktifkan Autostart & kunci app di recents.",
            batteryOk, "Atur"
        ) {
            open(
                ctx, Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:${ctx.packageName}")
                )
            )
        }
        OutlinedButton(onClick = { openAutostart(ctx) }, modifier = Modifier.fillMaxWidth()) {
            Text("Buka setelan Autostart (Xiaomi/Poco)")
        }

        Button(
            onClick = {
                val i = Intent(ctx, IslandService::class.java)
                if (running) {
                    ctx.stopService(i)
                    IslandState.setEnabled(ctx, false)
                    running = false
                } else {
                    ContextCompat.startForegroundService(ctx, i)
                    IslandState.setEnabled(ctx, true)
                    running = true
                }
            },
            enabled = overlayOk,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (running) "Matikan Notch" else "Nyalakan Notch")
        }

        Text("Tes tampilan", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                IslandState.notif.value = NotifInfo(
                    "test", "Pesan", "Budi", "Woi besok jadi nongkrong nggak?", null, null
                )
            }) { Text("Notif") }
            OutlinedButton(onClick = { IslandState.charge.value = ChargeInfo(67) }) { Text("Charge") }
            OutlinedButton(onClick = {
                IslandState.media.value = MediaInfo("Judul Lagu", "Nama Artis", null, true)
            }) { Text("Musik") }
            OutlinedButton(onClick = {
                IslandState.call.value = CallInfo(
                    key = "test-call", appName = "WhatsApp", caller = "Budi",
                    subtitle = "Panggilan suara masuk", icon = null, incoming = true,
                    content = null, answer = null, decline = null
                )
            }) { Text("Telepon") }
        }

        Text("Kalibrasi kamera", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(
            "Geser sampai celah tengah pas dengan punch-hole kamera (nyalakan notch & tekan tombol tes dulu).",
            fontSize = 13.sp
        )
        SliderRow("Celah tengah (kamera): ${cfg.gapDp} dp", cfg.gapDp, 10, 90) {
            IslandState.config.value = cfg.copy(gapDp = it)
        }
        SliderRow("Lebar kiri/kanan: ${cfg.sideDp} dp", cfg.sideDp, 40, 120) {
            IslandState.config.value = cfg.copy(sideDp = it)
        }
        SliderRow("Tinggi pill: ${cfg.heightDp} dp", cfg.heightDp, 24, 50) {
            IslandState.config.value = cfg.copy(heightDp = it)
        }
        SliderRow("Jarak dari atas: ${cfg.topDp} dp", cfg.topDp, 0, 30) {
            IslandState.config.value = cfg.copy(topDp = it)
        }
        OutlinedButton(
            onClick = { IslandState.saveConfig(ctx) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Simpan kalibrasi") }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun PermRow(
    title: String,
    desc: String,
    ok: Boolean,
    action: String,
    onClick: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(if (ok) "✓ Aktif" else "Belum")
            }
            Text(desc, fontSize = 13.sp)
            if (!ok) {
                Button(onClick = onClick) { Text(action) }
            }
        }
    }
}

@Composable
private fun SliderRow(label: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Column {
        Text(label, fontSize = 13.sp)
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = min.toFloat()..max.toFloat()
        )
    }
}

private fun open(ctx: Context, intent: Intent) {
    try {
        ctx.startActivity(intent)
    } catch (_: Exception) {
        try {
            ctx.startActivity(
                Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:${ctx.packageName}")
                )
            )
        } catch (_: Exception) {
        }
    }
}

private fun openAutostart(ctx: Context) {
    val i = Intent().setComponent(
        ComponentName(
            "com.miui.securitycenter",
            "com.miui.permcenter.autostart.AutoStartManagementActivity"
        )
    )
    open(ctx, i)
}
