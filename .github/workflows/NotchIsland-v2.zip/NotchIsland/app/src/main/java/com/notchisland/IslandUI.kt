package com.notchisland

import android.app.ActivityOptions
import android.app.PendingIntent
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private enum class Mode { Idle, Notif, Charge, Media, Call }

private val Green = Color(0xFF30D158)
private val Red = Color(0xFFFF453A)
private val Neutral = Color(0xFF3A3A3C)
private val Gray = Color(0xFF9A9AA0)
private val LightGray = Color(0xFFD0D0D5)
private val ExpandedWidth = 330.dp
private val PillGradient = Brush.verticalGradient(
    listOf(Color(0xFF232327), Color(0xFF050506))
)
private val PillBorder = Color(0x1AFFFFFF)

@Composable
fun IslandRoot() {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val cfg by IslandState.config.collectAsState()
    val notif by IslandState.notif.collectAsState()
    val charge by IslandState.charge.collectAsState()
    val media by IslandState.media.collectAsState()
    val call by IslandState.call.collectAsState()

    var expanded by remember { mutableStateOf(false) }
    var mediaTimedOut by remember { mutableStateOf(false) }

    // Musik yang di-pause disembunyikan setelah 6 detik
    LaunchedEffect(media?.isPlaying, media?.title) {
        mediaTimedOut = false
        if (media != null && media?.isPlaying == false) {
            delay(6000)
            mediaTimedOut = true
        }
    }

    val mode = when {
        call?.incoming == true -> Mode.Call   // panggilan masuk = prioritas tertinggi
        notif != null -> Mode.Notif
        call != null -> Mode.Call             // panggilan berlangsung (timer)
        charge != null -> Mode.Charge
        media != null && !mediaTimedOut -> Mode.Media
        else -> Mode.Idle
    }
    val isExpanded = expanded && mode != Mode.Idle

    LaunchedEffect(mode) { if (mode == Mode.Idle) expanded = false }

    // Panggilan masuk -> otomatis expand. Dijawab / selesai -> kembali compact.
    LaunchedEffect(call?.key, call?.incoming) { expanded = call?.incoming == true }

    // Notif & charging hilang sendiri kalau tidak di-expand
    LaunchedEffect(notif, charge, expanded) {
        if (!expanded) {
            if (notif != null) {
                delay(5000)
                IslandState.notif.value = null
            } else if (charge != null) {
                delay(4000)
                IslandState.charge.value = null
            }
        }
    }

    // Auto collapse setelah 9 detik
    LaunchedEffect(expanded, media?.isPlaying, media?.title, notif?.time, call?.incoming) {
        if (expanded && call?.incoming != true) {
            delay(9000)
            expanded = false
        }
    }

    // Muncul & hilang dengan efek "bloom" (membesar dari titik), bukan pop kaku
    AnimatedVisibility(
        visible = mode != Mode.Idle,
        enter = fadeIn(tween(160)) + scaleIn(
            initialScale = 0.5f,
            animationSpec = spring(dampingRatio = 0.68f, stiffness = 320f)
        ),
        exit = fadeOut(tween(140)) + scaleOut(
            targetScale = 0.5f,
            animationSpec = tween(160)
        )
    ) {
        val corner by animateDpAsState(
            targetValue = if (isExpanded) 30.dp else 20.dp,
            animationSpec = spring(dampingRatio = 0.8f, stiffness = 300f),
            label = "corner"
        )

        val dismiss: () -> Unit = {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            if (isExpanded) {
                expanded = false
            } else {
                when (mode) {
                    Mode.Notif -> IslandState.notif.value = null
                    Mode.Charge -> IslandState.charge.value = null
                    Mode.Media -> mediaTimedOut = true
                    Mode.Call -> Unit
                    Mode.Idle -> Unit
                }
            }
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(corner))
                .background(PillGradient)
                .border(1.dp, PillBorder, RoundedCornerShape(corner))
                .pointerInput(mode, isExpanded) {
                    var acc = 0f
                    detectVerticalDragGestures(
                        onDragStart = { acc = 0f },
                        onDragEnd = { if (acc < -30f) dismiss() },
                        onDragCancel = { acc = 0f },
                        onVerticalDrag = { _, d -> acc += d }
                    )
                }
                .tap {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    expanded = !expanded
                }
        ) {
            AnimatedContent(
                targetState = mode to isExpanded,
                transitionSpec = {
                    (fadeIn(tween(200, delayMillis = 60)) + scaleIn(
                        initialScale = 0.92f,
                        animationSpec = spring(dampingRatio = 0.75f, stiffness = 420f)
                    )) togetherWith (fadeOut(tween(90)) + scaleOut(
                        targetScale = 0.96f,
                        animationSpec = tween(110)
                    )) using SizeTransform(clip = false) { _, _ ->
                        spring(dampingRatio = 0.72f, stiffness = 240f)
                    }
                },
                label = "island"
            ) { (m, exp) ->
                when (m) {
                    Mode.Notif -> notif?.let { n ->
                        if (exp) {
                            NotifExpanded(n, cfg) {
                                openIntent(ctx, n.intent)
                                IslandState.notif.value = null
                                expanded = false
                            }
                        } else {
                            Compact(
                                cfg,
                                left = { AppIcon(n.icon, 22.dp) },
                                right = {
                                    Text(
                                        n.title,
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            )
                        }
                    }

                    Mode.Charge -> charge?.let { c ->
                        if (exp) {
                            ChargeExpanded(c, cfg)
                        } else {
                            Compact(
                                cfg,
                                left = {
                                    Icon(
                                        painterResource(R.drawable.ic_bolt), null,
                                        tint = Green, modifier = Modifier.size(18.dp)
                                    )
                                },
                                right = {
                                    Text(
                                        "${c.percent}%",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            )
                        }
                    }

                    Mode.Media -> media?.let { md ->
                        if (exp) {
                            MediaExpanded(md, cfg)
                        } else {
                            Compact(
                                cfg,
                                left = { Art(md.art, 22.dp) },
                                right = { if (md.isPlaying) Equalizer() }
                            )
                        }
                    }

                    Mode.Call -> call?.let { c ->
                        if (exp) {
                            CallExpanded(c, cfg) { expanded = false }
                        } else {
                            Compact(
                                cfg,
                                left = { AppIcon(c.icon, 22.dp) },
                                right = {
                                    if (c.incoming) {
                                        Text(
                                            c.caller,
                                            color = Green,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.incomingPulse()
                                        )
                                    } else {
                                        CallTimer(c.startedAt, Green, 12.sp)
                                    }
                                }
                            )
                        }
                    }

                    Mode.Idle -> Unit
                }
            }
        }
    }
}

// ---------- compact ----------

@Composable
private fun Compact(
    cfg: NotchConfig,
    left: @Composable () -> Unit,
    right: @Composable () -> Unit
) {
    Row(
        Modifier
            .height(cfg.heightDp.dp)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(cfg.sideDp.dp), contentAlignment = Alignment.CenterStart) { left() }
        Spacer(Modifier.width(cfg.gapDp.dp)) // area kamera punch-hole
        Box(Modifier.width(cfg.sideDp.dp), contentAlignment = Alignment.CenterEnd) { right() }
    }
}

// ---------- expanded ----------

@Composable
private fun NotifExpanded(n: NotifInfo, cfg: NotchConfig, onOpen: () -> Unit) {
    Column(
        Modifier
            .width(ExpandedWidth)
            .tap(onOpen)
            .padding(start = 18.dp, end = 18.dp, top = (cfg.heightDp + 2).dp, bottom = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.Top) {
            AppIcon(n.icon, 40.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(n.appName, color = Gray, fontSize = 11.sp, maxLines = 1)
                Text(
                    n.title,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (n.text.isNotBlank()) {
                    Text(
                        n.text,
                        color = LightGray,
                        fontSize = 13.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun MediaExpanded(m: MediaInfo, cfg: NotchConfig) {
    Column(
        Modifier
            .width(ExpandedWidth)
            .padding(start = 18.dp, end = 18.dp, top = (cfg.heightDp + 2).dp, bottom = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Art(m.art, 56.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    m.title,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    m.artist,
                    color = Gray,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (m.isPlaying) Equalizer()
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CtrlButton(R.drawable.ic_prev, 28.dp) {
                IslandState.controller?.transportControls?.skipToPrevious()
            }
            CtrlButton(if (m.isPlaying) R.drawable.ic_pause else R.drawable.ic_play, 38.dp) {
                val tc = IslandState.controller?.transportControls
                if (m.isPlaying) tc?.pause() else tc?.play()
            }
            CtrlButton(R.drawable.ic_next, 28.dp) {
                IslandState.controller?.transportControls?.skipToNext()
            }
        }
    }
}

@Composable
private fun ChargeExpanded(c: ChargeInfo, cfg: NotchConfig) {
    Column(
        Modifier
            .width(ExpandedWidth)
            .padding(start = 18.dp, end = 18.dp, top = (cfg.heightDp + 2).dp, bottom = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                painterResource(R.drawable.ic_bolt), null,
                tint = Green, modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text("Mengisi daya", color = Gray, fontSize = 12.sp)
                Text(
                    "${c.percent}%",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        val progress by animateFloatAsState(
            targetValue = c.percent / 100f,
            animationSpec = spring(dampingRatio = 0.8f, stiffness = 160f),
            label = "charge"
        )
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = Green,
            trackColor = Color(0xFF2C2C2E)
        )
    }
}

@Composable
private fun CallExpanded(c: CallInfo, cfg: NotchConfig, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    Column(
        Modifier
            .width(ExpandedWidth)
            .padding(start = 18.dp, end = 18.dp, top = (cfg.heightDp + 2).dp, bottom = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(c.icon, 44.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(c.appName, color = Gray, fontSize = 11.sp, maxLines = 1)
                Text(
                    c.caller,
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (c.incoming) {
                    Text(
                        c.subtitle.ifBlank { "Panggilan masuk" },
                        color = LightGray,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                } else {
                    CallTimer(c.startedAt, Green, 13.sp)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            // Tolak / Tutup. Kalau app tidak menyediakan tombolnya, cuma sembunyikan pill.
            val hasDecline = c.decline != null
            CallButton(
                label = when {
                    !hasDecline -> "Sembunyikan"
                    c.incoming -> "Tolak"
                    else -> "Tutup"
                },
                color = if (hasDecline) Red else Neutral,
                modifier = Modifier.weight(1f)
            ) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                if (hasDecline) openIntent(ctx, c.decline)
                IslandState.call.value = null
                onDone()
            }
            if (c.incoming) {
                val hasAnswer = c.answer != null
                CallButton(
                    label = if (hasAnswer) "Jawab" else "Buka",
                    color = if (hasAnswer) Green else Neutral,
                    modifier = Modifier.weight(1f)
                ) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    openIntent(ctx, if (hasAnswer) c.answer else c.content)
                }
            }
        }
    }
}

// ---------- potongan kecil ----------

/** Pulsing lembut buat teks panggilan masuk (biar terasa "hidup"). */
@Composable
private fun Modifier.incomingPulse(): Modifier {
    val t = rememberInfiniteTransition(label = "pulse")
    val alpha by t.animateFloat(
        initialValue = 0.45f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
        label = "pulseAlpha"
    )
    return graphicsLayer { this.alpha = alpha }
}

@Composable
private fun AppIcon(bmp: Bitmap?, size: Dp) {
    if (bmp != null) {
        val img = remember(bmp) { bmp.asImageBitmap() }
        Image(
            img, null,
            Modifier
                .size(size)
                .clip(RoundedCornerShape(size / 4)),
            contentScale = ContentScale.Crop
        )
    } else {
        Box(
            Modifier
                .size(size)
                .clip(RoundedCornerShape(size / 4))
                .background(Color(0xFF2C2C2E))
        )
    }
}

@Composable
private fun Art(bmp: Bitmap?, size: Dp) = AppIcon(bmp, size)

/** Tombol musik dengan efek "mekek" (scale) saat ditekan. */
@Composable
private fun CtrlButton(res: Int, size: Dp, onClick: () -> Unit) {
    val inter = remember { MutableInteractionSource() }
    val pressed by inter.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.78f else 1f,
        animationSpec = spring(stiffness = 600f),
        label = "ctrlScale"
    )
    Box(
        Modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clickable(interactionSource = inter, indication = null, onClick = onClick)
            .padding(8.dp)
    ) {
        Icon(painterResource(res), null, tint = Color.White, modifier = Modifier.size(size))
    }
}

/** Tombol pill dengan efek scale saat ditekan + haptic. */
@Composable
private fun CallButton(label: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    val inter = remember { MutableInteractionSource() }
    val pressed by inter.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.93f else 1f,
        animationSpec = spring(stiffness = 600f),
        label = "callScale"
    )
    val haptic = LocalHapticFeedback.current
    Box(
        modifier
            .height(42.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(21.dp))
            .background(color)
            .clickable(interactionSource = inter, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CallTimer(startedAt: Long, color: Color, size: TextUnit) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(startedAt) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val s = ((now - startedAt) / 1000).coerceAtLeast(0)
    Text(
        "%02d:%02d".format(s / 60, s % 60),
        color = color,
        fontSize = size,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun Equalizer(color: Color = Green, height: Dp = 14.dp) {
    val t = rememberInfiniteTransition(label = "eq")
    val a by t.animateFloat(
        initialValue = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(420, easing = LinearEasing), RepeatMode.Reverse),
        label = "a"
    )
    val b by t.animateFloat(
        initialValue = 0.4f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(560, easing = LinearEasing), RepeatMode.Reverse),
        label = "b"
    )
    val c by t.animateFloat(
        initialValue = 0.2f, targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(350, easing = LinearEasing), RepeatMode.Reverse),
        label = "c"
    )
    Row(
        Modifier.height(height),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        listOf(a, b, c).forEach {
            Box(
                Modifier
                    .width(3.dp)
                    .fillMaxHeight(it)
                    .clip(RoundedCornerShape(2.dp))
                    .background(color)
            )
        }
    }
}

@Composable
private fun Modifier.tap(onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick
    )

private fun openIntent(ctx: Context, pi: PendingIntent?) {
    if (pi == null) return
    try {
        val opts = if (Build.VERSION.SDK_INT >= 34) {
            ActivityOptions.makeBasic()
                .setPendingIntentBackgroundActivityStartMode(
                    ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                ).toBundle()
        } else null
        pi.send(ctx, 0, null, null, null, null, opts)
    } catch (_: Exception) {
    }
}
